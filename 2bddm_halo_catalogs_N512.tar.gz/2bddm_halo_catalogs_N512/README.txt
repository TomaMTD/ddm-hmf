AHF halo catalogues (*.AHF_halos only) for the L1000 N512 runs of the 2-body decaying DM project.
Box 1000 Mpc/h, 512^3 particles, particle mass 6.35e11 Msun/h, NminPerHalo = 100.
Cosmology: h=0.6776, Om0=0.307, OL0=0.693, sigma8=0.882531, ns=0.9665.

Per simulation:
  200c/  Dvir=200, RhoVir=0 (critical density), MaxGatherRad=3.0 Mpc/h
  200m/  Dvir=200, RhoVir=1 (background density), MaxGatherRad=5.0 Mpc/h
Snapshots: 00020 (z=2.350), 00040 (z=1.083), 00100 (z=0.000).

Units: positions kpc/h, masses Msun/h, radii kpc/h, velocities km/s.
Column names are in the header line of each file. Host halos have hostHalo (col 2) == -1.
Simulation folder names encode the DDM parameters: f = decaying fraction,
invG = 1/Gamma in Gyr, vk = kick velocity in km/s.
